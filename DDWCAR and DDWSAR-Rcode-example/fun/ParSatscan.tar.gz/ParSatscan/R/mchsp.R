#' Calculate MCHS-P based on the detected clusters
#'
#' \code{mchsp} returns the value of MCHS-P according to the detected clusters.
#'
#' @param pop A vector of integer indicating the total population in each
#'            spatial unit.
#' @param case A vector of integer indicating the total cases in each
#'             spatial unit.
#' @param id A vector indicating the only identification name of each spatial
#'           unit, which must be the same order with pop and case.
#' @param clusterID A subset of the elements of id, indicating these ids in
#'                  clusters.
#' @param cluster A vector of numeric or character, indicating which cluster the
#'                ids in clusterID belongs to, having the same length as
#'                clusterID.
#' @param gallist Seen in \code{\link{merge_clusters}}.
#'
#' @details \code{mchsp} support clusters with both highrate and lowrate.The
#'          order of elements in gallist must be coincident with that of id.
#'
#' @examples
#' data("NUSdata")
#' data("clusterdata")
#' data("gallist")
#' x <- mchsp(pop = NUSdata$pop,case = NUSdata$case,id = NUSdata$code,
#'           clusterID = clusterdata$clusterID,cluster = clusterdata$clusters,
#'           gallist = gallist)
mchsp <- function(pop,case,id,clusterID,cluster,gallist){

  if (length(cluster) != length(clusterID)) stop("the length of cluster and clusterID must be equal")
  if(sum(duplicated(clusterID))!=0) stop("there are duplicated elements in clusterID")
  # merge cluster based on contiguous relationship
  clusterID <- as.character(clusterID)
  id <- as.character(id)
  mercluster <- merge_clusters(gallist = gallist,clusterID = clusterID,cluster = cluster)
  clusterID <- mercluster[[1]]
  cluster <- mercluster[[2]]
  # the basic index
  names(pop) <- names(case) <- id
  spop <- sum(pop)
  spop_cluster <- sum(pop[clusterID])
  spop_base <- spop - spop_cluster
  scase <- sum(case)
  scase_cluster <- sum(case[clusterID])
  scase_base <- scase - scase_cluster
  pmean <- scase/spop
  # LL under H0
  ll_h0 <- scase * log(scase/spop)
  # calculate LLR(numerator of MCHS-P)
  CalLL <- function(x){
    x <- as.character(x) ######## this step is necessary,otherwise x will be coerced into factor
    ll <- ifelse(sum(case[x])==0,0,sum(case[x]) * log(sum(case[x])/sum(pop[x])))
    return(ll)
  }
  clusterLL <- by(data = clusterID,INDICES = cluster,FUN = CalLL,simplify = T)
  llr <- sum(clusterLL) + scase_base * log(scase_base/spop_base) - ll_h0
  # calculate approximate LLR(denominator of MCHS-P)
  mcs <- id[case/pop > pmean]
  mchs <- merge_clusters(gallist = gallist,clusterID = mcs,cluster = 1:length(mcs))
  ll_app <- by(data = mchs[[1]],INDICES = mchs[[2]],FUN = CalLL,simplify = T)
  scase0 <- scase - sum(case[mcs])
  spop0 <- spop - sum(pop[mcs])
  llr_app <- sum(ll_app) + scase0 * log(scase0/spop0) - ll_h0
  # calculate MCHS-P
  return(llr/llr_app)
}
