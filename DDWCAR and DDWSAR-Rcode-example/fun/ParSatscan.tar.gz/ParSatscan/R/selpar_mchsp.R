#' Select parameter according to MCHS-P
#'
#' \code{selpar_mchsp} slects the optimal maximum window from a series of
#' maximum windows for spatial scan statistic according to MCHS-P.
#'
#' @param pop,case,id,gallist Seen in \code{\link{mchsp}}.
#' @param sizes A vectot of numeric indicting the maximum windows to tune.
#' @param sslocation,location Seen in \code{\link{satscan}}.
#' @param alpha A positive numeric indicating the significant level.
#' @param Allresult A logic value indicating whether you need to save the
#'                  detected result under each sizes in global environment.
#' @param prmsave: A logic value indicating whether you need to save prmfiles
#'                 in your computer.
#' @param prmname: Character indicating the name of prmfile saved. Only when
#'                 prmsave = T, that is useful.
#' @param ... Seen in \code{\link{satscan}}. Often the parameters: verbose,
#'            cleanup, and ssbatchfilename are needed to reset.
#' @return A list containing the following components:
#'         Osize the optimal size
#'         MchspSize A data.frame containing the values of MCHS-P under each size
#'         Oresult The detected result under the optimal size.
#'         Aresult It is available only when Allresult is true. Containing the
#'                 detected results under each size.
#'
#' @details This function requires that the events occur following poisson
#'          distribution.
#'
#' @examples
#' library(rsatscan)
#' setwd("D:/R/setwd")
#' data("NUSdata")
#' data("clusterdata")
#' data("gallist")
#' write.geo(NUSdata[,c("code","x","y")],filename = "NUS",location = getwd())
#' write.cas(NUSdata[,c(1,5)],filename = "NUS",location = getwd())
#' write.pop(data.frame(NUSdata[[1]],"unspecified",NUSdata[[6]]),filename = "NUS",location = getwd())
#' invisible(ss.options(reset = T))
#' #select parameters excluding the maximum window sizes, 3.4 has no effect.
#' ss.options(list(CaseFile= paste0(getwd(),"/NUS.cas"),
#'                 PrecisionCaseTimes=0,
#'                 PopulationFile=paste0(getwd(),"/NUS.pop"),
#'                 CoordinatesFile=paste0(getwd(),"/NUS.geo"),
#'                 CoordinatesType=0,
#'                 ReportGiniClusters="n",
#'                 MaxSpatialSizeInPopulationAtRisk=3.4
#' ))
#' # The location where SaTscan was installed.
#' sslocation0 <- "D:/Program Files (x86)/SaTScan"
#' xx <- selpar_mchsp(pop = NUSdata$pop,case = NUSdata$case,sizes = 1:50,
#'                 id = NUSdata$code,prmsave = F,sslocation = sslocation0,
#'                 gallist = gallist,verbose=F)
selpar_mchsp <- function(pop,case,id,sizes = 1:50,gallist,sslocation,location = getwd(),
                        alpha = 0.05,Allresult = F,prmsave = F,prmname = "SelParMchsp", ...){
  n <- length(sizes)
  Aresult <- list() # all result
  Oresult <- NULL # optimal result
  Osize <- NULL # optimal size
  MCHSP <- NULL
  for (i in 1:n) {
    cat(sprintf("The running maximal window size is %s",sizes[i]),"\n")
    ss.options(invals = list(MaxSpatialSizeInPopulationAtRisk=sizes[i]))
    write.ss.prm(location = location,filename = paste0(prmname,sizes[i]))
    xx <- satscan(prmlocation = location,prmfilename = paste0(prmname,sizes[i]),sslocation = sslocation, ...)
    clusters <- subset(xx$gis,P_VALUE <= alpha,select = 1:2)
    mchspi <- mchsp(pop = pop,case = case,id = id,gallist = gallist,clusterID = clusters[[1]],cluster = clusters[[2]])
    MCHSP <- c(MCHSP,mchspi)
    Aresult[[i]] <- xx
    if(prmsave == F) file.remove(paste0(location,"\\",prmname,sizes[i],".prm"))
  }
  Osize <- sizes[which.max(MCHSP)]
  Oresult <- Aresult[[which.max(MCHSP)]]
  if(Allresult == F) Result <- list(Osize=Osize,MchspSize=data.frame(size=sizes,MCHSP=MCHSP),Oresult=Oresult)
  else Result <- list(Osize=Osize,MchsPSize=data.frame(size=sizes,MCHSP=MCHSP),Oresult=Oresult,Aresult=Aresult)
  return(Result)
}
