#' Merges the detected clusters
#'
#' \code{merge_clusters} merges the detected clusters according to their spatial
#' contiguous relationship
#'
#' @param gallist An list indicating contiguous relationship between any two
#'                spatial units, which often comes from \code{\link{read.gal}}
#'                in package \code{\link{spdep}}.
#' @param clusterID Seen in \code{\link{mchsp}}.
#' @param cluster Seen in \code{\link{mchsp}}.
#' @return The merged clusters.
#'
#' @examples
#' data("clusterdata")
#' data("gallist")
#' x <- merge_clusters(gallist = gallist,clusterID = clusterdata$clusterID,
#'                     cluster = clusterdata$clusters)
merge_clusters <- function(gallist,clusterID,cluster){

  if(sum(duplicated(clusterID))!=0) stop("there are duplicated elements in clusterID")
  ucluster <- unique(cluster)
  names(ucluster) <- 1:length(ucluster)
  cluster <- as.integer(names(ucluster[match(cluster,ucluster)]))
  clusterID <- as.character(clusterID)
  region.id <- as.character(attr(gallist,"region.id"))
  if(length(setdiff(clusterID,region.id)) != 0) stop("clusterID must be a subset of gallist's region.id")
  clusters <- data.frame(code = clusterID,cluster = cluster)
  num_cluster <- max(clusters[,2])
  clusters$code <- match(clusters$code,region.id)

  mergedcluster <- list() # 合并好的cluster
  clustering <- list() # 待合并的cluster
  for (i in 1:num_cluster) {
    clustering[[i]] <- subset(clusters,cluster ==i,select = code)$code
  }

  while (length(clustering)>=2) {
    cluster1 <- clustering[[1]]
    cluster1_nb <- unique(unlist(gallist[cluster1])) # 与clusteri 临接的code 位置
    clusterm <- clustering[2:length(clustering)] #
    xx <- unlist(lapply(clusterm,function(x) length(intersect(cluster1_nb,x))==T))
    if (sum(xx)==0){
      mergedcluster <- c(mergedcluster,clustering[1])
      clustering <- clusterm
    } else{
      mergedcluster <- mergedcluster
      cluster1 <- c(cluster1,unlist(clusterm[xx]))
      clustering <- c(list(cluster1),clusterm[!xx])
    }
  }
  mergedcluster <- c(mergedcluster,clustering)
  len <- unlist(lapply(mergedcluster,length))
  mcluster <- data.frame(code = unlist(mergedcluster),cluster = rep(1:length(mergedcluster),len))
  mcluster$code <- region.id[mcluster$code]
  return(mcluster)
}
