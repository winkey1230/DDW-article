#' Calculate MCS-P based on the detected clusters
#'
#' \code{mcsp} returns the value of MCS-P according to the detected clusters.
#'
#' @param pop A vector of integer indicating the total population in each
#'            spatial unit.
#' @param case A vector of integer indicating the total cases in each
#'             spatial unit.
#' @param id A vector indicating the only identification name of each spatial
#'           unit, which must be the same order with pop and case.
#' @param clusterID A subset of the elements of id, indicating these ids in
#'                  clusters.
#' @param cluster A vector of numeric or character, indicating which cluster the
#'                ids in clusterID belongs to, having the same length as
#'                clusterID. It will be useful only when both = T.
#' @param both A logical value indicating. True is default, which indicates
#'             clusters with both highrate and lowrate. False indicates clusters
#'             with either highrate or lowrate.
#'
#' @details \code{mcsp} support clusters with both highrate and lowrate.
#'
#' @examples
#' data("NUSdata")
#' data("clusterdata")
#' x <- mcsp(pop = NUSdata$pop,case = NUSdata$case,id = NUSdata$code,
#'           clusterID = clusterdata$clusterID)
mcsp <- function(pop,case,id,clusterID,cluster = NULL,both = F){

  if(sum(duplicated(clusterID))!=0) stop("there are duplicated elements in clusterID")
  # the basic index
  clusterID <- as.character(clusterID)
  id <- as.character(id)
  names(pop) <- names(case) <- id
  spop <- sum(pop)
  spop_cluster <- sum(pop[clusterID])
  spop_base <- spop - spop_cluster
  scase <- sum(case)
  scase_cluster <- sum(case[clusterID])
  scase_base <- scase - scase_cluster
  pmean <- scase/spop
  # LL under H0
  ll_h0 <- scase * log(scase/spop)
  # calculate LLR(numerator of MCS-P)
  if (both == T){
    if (length(cluster) != length(clusterID)) stop("the length of cluster and clusterID must be equal")
    CalHL <- function(x){
      x <- as.character(x)
      p <- sum(case[x])/sum(pop[x])
      risk <- ifelse(p >= pmean, "H", "L")
      return(risk)
    }
    clusterp <- by(data = clusterID,INDICES = cluster,FUN = CalHL,simplify = T)
    rate <- clusterp[as.character(cluster)]
    CalLL <- function(x){
      x <- as.character(x)
      ll <- ifelse(sum(case[x])==0,0,sum(case[x]) * log(sum(case[x])/sum(pop[x])))
      return(ll)
    }
    clusterLL <- by(data = clusterID,INDICES = rate,FUN = CalLL,simplify = T)
    llr <- sum(clusterLL) + scase_base * log(scase_base/spop_base) - ll_h0
  } else {
    llr <- ifelse(scase_cluster == 0,
                  scase_base * log(scase_base/spop_base) - ll_h0,
                  scase_base * log(scase_base/spop_base) + scase_cluster * log(scase_cluster/spop_cluster) - ll_h0)
  }
  # calculate approximate LLR(denominator of MCS-P)
  id1 <- id[case/pop > pmean]
  scase1 <- sum(case[id1])
  scase0 <- scase - scase1
  spop1 <- sum(pop[id1])
  spop0 <- spop - spop1
  llr_app <- scase1 * log(scase1/spop1) + scase0 * log(scase0/spop0) - ll_h0
  # calculate MCS-P
  return(llr/llr_app)
}
