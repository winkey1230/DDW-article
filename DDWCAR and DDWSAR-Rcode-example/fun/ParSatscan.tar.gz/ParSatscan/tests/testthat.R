library(testthat)
library(ParSatscan)

test_that("mcsp equals to 0.68207590914 in current example data",{
  expect_equal(mcsp(pop = NUSdata$pop,case = NUSdata$case,id = NUSdata$code,
                    clusterID = clusterdata$clusterID),0.68207590914)
})
test_that("mchsp equals to 0.64705504882 in current example data",{
  expect_equal(mchsp(pop = NUSdata$pop,case = NUSdata$case,id = NUSdata$code,
                    clusterID = clusterdata$clusterID),0.64705504882)
})
